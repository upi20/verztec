<?php
/**
 * This file contains process to forward data only
 *
 * @category  Core
 * @package   KoolReport
 * @author    KoolPHP Inc <support@koolphp.net>
 * @copyright 2017-2028 KoolPHP Inc
 * @license   MIT License https://www.koolreport.com/license#mit-license
 * @link      https://www.koolphp.net
 */

 namespace koolreport\processes;

use \koolreport\core\Process;

class Forward extends Process
{
    
}