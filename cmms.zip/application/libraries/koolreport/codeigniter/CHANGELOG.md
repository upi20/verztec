# Change Log

## Version 1.8.0

1. Change README

## Version 1.7.0

1. Update the CIDataSource to work with latest version of KoolReport

## Version 1.6.0

1. Fix the CIDataSource mistaken break in line 90

## Version 1.5.0

1. Enhance assets url settings

## Version 1.0.0

1. Adding `Friendship` class to communicate with CodeIgniter
2. Adding `CIDataSource` class to handle data source from CodeIgniter